#!/bin/bash
systemctl reload nginx
